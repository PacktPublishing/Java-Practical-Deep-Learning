package com.packtpub.javamlbook.chap4;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import weka.core.converters.CSVLoader;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.RemoveType;

public class Crm {

	// static final Enum;
	static final int PREDICT_CHURN = 0, PREDICT_APPETENCY = 1,
			PREDICY_UPSELL = 3;
	static final String path = "/Users/bostjan/Dropbox/ML Java Book/book/datasets/chap4/";

	public static void main(String args[]) throws Exception {

		// Instances train_data = loadData(
		// path + "orange_small_train.data",
		// path + "orange_small_train_churn.labels.txt");
		// System.out.println(train_data.toSummaryString());
		//
		// Instances test_data = loadData(path + "orange_small_test.data", path
		// + "orange_small_test.labeles", PREDICT_CHURN);
		// System.out.println(test_data.toSummaryString());

		Classifier baselineNB = new NaiveBayes();

		double resNB[] = evaluate(baselineNB);
		System.out.println("Naive Bayes\n" + "\tchurn:     " + resNB[0] + "\n"
				+ "\tappetency: " + resNB[1] + "\n" + "\tup-sell:   "
				+ resNB[2] + "\n" + "\toverall:   " + resNB[3] + "\n");

		//
		// // cross-validation
		// Evaluation eval = new Evaluation(train_data);
		// eval.crossValidateModel(cl, train_data, 10, new Random(1),
		// new Object[] {});
		// System.out.println(eval.toSummaryString());

	}

	public static double[] evaluate(Classifier model) throws Exception {

		double results[] = new double[4];

		String[] labelFiles = new String[] { "churn", "appetency", "upselling" };

		double overallScore = 0.0;
		for (int i = 0; i < labelFiles.length; i++) {

			// Load data
			Instances train_data = loadData(path + "orange_small_train.data",
					path + "orange_small_train_" + labelFiles[i]
							+ ".labels.txt");
			// Instances test_data = loadData( path + "orange_small_train.data",
			// path + "orange_small_train_"+labelFiles[i]+".labels.txt");

			// Build model
			// model.buildClassifier(train_data);

			// Evaluate on test data
			// Evaluation eval = new Evaluation(test_data);
			// eval.evaluateModel(model, test_data);

			// cross-validate the data
			Evaluation eval = new Evaluation(train_data);
			eval.crossValidateModel(model, train_data, 5, new Random(1));

			// Save results
			results[i] = eval.areaUnderROC(train_data.classAttribute()
					.indexOfValue("1"));
			overallScore += results[i];
		}
		// Get average results over all three problems
		results[3] = overallScore / 3;
		return results;
	}

	public static Instances loadData(String pathData, String pathLabeles)
			throws Exception {

		/*
		 * Load data
		 */
		CSVLoader loader = new CSVLoader();
		loader.setFieldSeparator("\t");
		loader.setNominalAttributes("191-last");
		loader.setSource(new File(pathData));
		Instances data = loader.getDataSet();

		// remove String attribute types
		RemoveType removeString = new RemoveType();
		removeString.setOptions(new String[] { "-T", "string" });
		removeString.setInputFormat(data);
		Instances filteredData = Filter.useFilter(data, removeString);
		data.deleteStringAttributes();

		/*
		 * Load labels
		 */
		loader = new CSVLoader();
		loader.setFieldSeparator("\t");
		loader.setNoHeaderRowPresent(true);
		loader.setNominalAttributes("first-last");
		loader.setSource(new File(pathLabeles));
		Instances labeles = loader.getDataSet();
		// System.out.println(labeles.toSummaryString());

		// Append label as class value
		Instances labeledData = Instances.mergeInstances(filteredData, labeles);

		// set it as a class value
		labeledData.setClassIndex(labeledData.numAttributes() - 1);

		System.out.println(labeledData.toSummaryString());

		return labeledData;
	}

}
